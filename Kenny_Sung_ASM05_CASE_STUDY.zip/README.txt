Hi Marcial,

Please extract the zip file and import the java file into eclipse and the sql file to oracle database. 
After making sure all of the necessary components are accurate and in order, please run the application.
To use this web based application please start by registering a new user and fill out all necessary info.
After which you can check the policy status with entering your newly created user in the login page. 

These are the incidents #s for the servicenow portion for your reference:
Simple - INC0010077
Simple - INC0010080
Medium - INC0010084	
Medium - INC0010087
Complex - INC0010094

As you can see all above are displayed as incidents, but you may always see each inividual escalation (problem) and change requeset within the incident for your convenience. 

Thanks,
Kenny   